# Arduino_Tools
[![GitHub release](https://img.shields.io/github/release/stm32duino/Arduino_Tools.svg)](https://github.com/stm32duino/Arduino_Tools/releases/latest)
[![GitHub commits](https://img.shields.io/github/commits-since/stm32duino/Arduino_Tools/2017.8.31.svg)](https://github.com/stm32duino/Arduino_Tools/compare/2017.8.31...master)

Contains upload tools for STM32 based boards and some other usefull scripts (ex: [genpinmap](https://github.com/stm32duino/Arduino_Tools/tree/master/src/genpinmap))
