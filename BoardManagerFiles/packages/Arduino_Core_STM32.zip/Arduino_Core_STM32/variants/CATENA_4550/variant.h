/*
 *******************************************************************************
 * Copyright (c) 2017, STMicroelectronics
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of STMicroelectronics nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *******************************************************************************
 */

#ifndef _VARIANT_ARDUINO_STM32_
#define _VARIANT_ARDUINO_STM32_

/*----------------------------------------------------------------------------
 *        Headers
 *----------------------------------------------------------------------------*/

#include "Arduino.h"

#ifdef __cplusplus
extern "C"{
#endif // __cplusplus

/*----------------------------------------------------------------------------
 *        Pins
 *----------------------------------------------------------------------------*/
#include "PeripheralPins.h"

extern const PinName digitalPin[];

// Enum defining pin names to match digital pin number --> Dx
// !!!
// !!! Copy the digitalPin[] array in variant.cpp
// !!! and remove all '_': PX_n --> PXn
// !!! For NC, suffix by _x where x is the number of NC:
// !!!   NC_1, NC_2,...
// !!! For duplicated pin name, suffix by _x where x is the number of pin:
// !!! PA7, PA7_2, PA7_3,...
enum {
  PA10, //D0      D0_RX
  PA9,  //D1      D1_TX
  PA7,  //D2      RADIO_MOSI   Murata internal
  PA6,  //D3      RADIO_MISO   Murata internal
  PB3,  //D4      RADIO_SCK    Murata internal
  PB5,  //D5      D5
  PA13, //D6      D6_SWDIO
  PA15, //D7      RADIO_NSS    Murata internal
  PC0,  //D8      RADIO_RESET  Murata internal
  PA14, //D9      D9_SWCLK
  NC_1, //D10     PH1_OSC_OUT
  NC_2, //D11     PH0_OSC_IN
  PB7,  //D12     D12
  PB2,  //D13     D13_LED
  PA0,  //D14/A0
  PA5,  //D15/A1
  PA4,  //D16/A2
  PA3,  //D17/A3  A3_VBAT_DET
  PA2,  //D18/A4  A4_VBUS_DET
  PB12, //D19     NSS
  PB9,  //D20     SDA
  PB8,  //D21     SCL
  PB14, //D22     MISO
  PB15, //D23     MOSI
  PB13, //D24     SCK
  PB4,  //D25     RADIO_DIO_0  Murata internal
  PB1,  //D26     RADIO_DIO_1  Murata internal
  PB0,  //D27     RADIO_DIO_2  Murata internal
  PC13, //D28     RADIO_DIO_3  Murata internal
  PA1,  //D29     RADIO_ANT_SWITCH_RX       CRF1  Murata internal
  PC1,  //D30     RADIO_ANT_SWITCH_TX_BOOST CRF3  Murata internal
  PC2,  //D31     RADIO_ANT_SWITCH_TX_RFO   CRF2  Murata internal
  PEND
};
// Enum defining Arduino style alias for analog pin number --> Ax
// !!!
// !!! It must be aligned with the number of analog PinName
// !!! defined in digitalPin[] array in variant.cpp
// !!!
enum {
  A_START_AFTER = D13, // pin number preceding A0
  A0,  A1,  A2,  A3,  A4,
  AEND
};

//ADC resolution is 12bits
#define ADC_RESOLUTION          12
#define DACC_RESOLUTION         12

//PWR resolution
#define PWM_RESOLUTION          8
#define PWM_FREQUENCY           1000
#define PWM_MAX_DUTY_CYCLE      255

//On-board LED pin number
#define LED_BUILTIN             D13
#define LED_RED                 LED_BUILTIN

//On-board user button
//#define USER_BTN                NC


//SPI definitions
#define RADIO_SS                D7
#define RADIO_MOSI              D2
#define RADIO_MISO              D3
#define RADIO_SCK               D4
#define RADIO_RESET             D8

#define FLASH_SS                D19
#define FLASH_MOSI              D23
#define FLASH_MISO              D22
#define FLASH_SCK               D24

#define SS                      RADIO_SS   // Default for Arduino connector compatibility
#define MOSI                    RADIO_MOSI // Default for Arduino connector compatibility
#define MISO                    RADIO_MISO // Default for Arduino connector compatibility
#define SCK                     RADIO_SCK  // Default for Arduino connector compatibility

//I2C Definitions
#define SDA                     D20 // Default for Arduino connector compatibility
#define SCL                     D21 // Default for Arduino connector compatibility

//Timer Definitions
//Do not use timer used by PWM pins when possible. See PinMap_PWM in PeripheralPins.c
#define TIMER_TONE              TIM6
#define TIMER_UART_EMULATED     TIM7

//Do not use basic timer: OC is required
#define TIMER_SERVO             TIM2  //TODO: advanced-control timers don't work

#define DEBUG_UART              ((USART_TypeDef *) USART1) // ex: USART3

// UART Emulation (uncomment if needed, required TIM1)
//#define UART_EMUL_RX            PX_n // PinName used for RX
//#define UART_EMUL_TX            PX_n // PinName used for TX

// Serial Pin Firmata
#define PIN_SERIAL_RX           D0
#define PIN_SERIAL_TX           D1
// Define as many PIN_SERIALX than desired
//#define PIN_SERIAL1_RX          Dx
//#define PIN_SERIAL1_TX          Dx
//...

#ifdef __cplusplus
} // extern "C"
#endif
/*----------------------------------------------------------------------------
 *        Arduino objects - C++ only
 *----------------------------------------------------------------------------*/

#ifdef __cplusplus
// declare here as many UART objects than defined in variant.cpp
extern HardwareSerial Serial;
//extern HardwareSerial SerialX;
//...

// These serial port names are intended to allow libraries and architecture-neutral
// sketches to automatically default to the correct port name for a particular type
// of use.  For example, a GPS module would normally connect to SERIAL_PORT_HARDWARE_OPEN,
// the first hardware serial port whose RX/TX pins are not dedicated to another use.
//
// SERIAL_PORT_MONITOR        Port which normally prints to the Arduino Serial Monitor
//
// SERIAL_PORT_USBVIRTUAL     Port which is USB virtual serial
//
// SERIAL_PORT_LINUXBRIDGE    Port which connects to a Linux system via Bridge library
//
// SERIAL_PORT_HARDWARE       Hardware serial port, physical RX & TX pins.
//
// SERIAL_PORT_HARDWARE_OPEN  Hardware serial ports which are open for use.  Their RX & TX
//                            pins are NOT connected to anything by default.
#define SERIAL_PORT_MONITOR   Serial
#define SERIAL_PORT_HARDWARE  Serial
#endif

#endif /* _VARIANT_ARDUINO_STM32_ */
